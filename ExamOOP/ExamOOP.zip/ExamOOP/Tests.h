#pragma once
#include "Controller.h"
#include <assert.h>
class Tests
{
public:
	Tests();
	~Tests();
	void testController();
	void testAll();
};

