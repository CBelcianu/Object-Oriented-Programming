#include "ExamOOP.h"

ExamOOP::ExamOOP(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
