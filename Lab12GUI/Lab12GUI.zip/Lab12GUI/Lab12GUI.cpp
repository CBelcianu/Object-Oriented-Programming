#include "Lab12GUI.h"

Lab12GUI::Lab12GUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
