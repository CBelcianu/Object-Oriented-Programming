#pragma once

class Tests
{
public:
	static void testDog();
	static void testDynamicVector();
	static void testRepository();
	static void testController();

	static void testAll();
};
