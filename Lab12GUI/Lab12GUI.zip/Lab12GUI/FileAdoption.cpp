#include "FileAdoption.h"


FileAdoption::FileAdoption(const std::string& filename)
{
	this->filename = filename;
}
